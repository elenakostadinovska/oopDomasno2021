public class MainClass {
    public static void main(String[] args) {
        PC pc1 = new PC();

        pc1.prvMetod(4,500);
    }
}
